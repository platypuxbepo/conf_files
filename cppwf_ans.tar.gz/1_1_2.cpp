// Exercise 1.1.2

#include <iostream>
using namespace std;

int main()
{
    cout << "Brian Overland ";
    return 0;
}