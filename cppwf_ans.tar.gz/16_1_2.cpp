// Exercise 16.1.2.
//

#include <iostream>
#include <string>
using namespace std;

class IAnimal {            // Base class.
public:
    virtual void speak() = 0;
};

// Each of these class are derived from IAnimal
// and inheret the speak() virtual function;
// however, each implements that function differently.

class Dog : public IAnimal {
    void speak();
};

class Cat : public IAnimal {
    void speak();
};

class Cow : public IAnimal {
    void speak();
};


int main()
{
    IAnimal *critters[3];      // Array of 3 pointers.

    critters[0] = new Dog();   // Point to these
    critters[1] = new Cat();   // three derived objects.
    critters[2] = new Cow();

    // Each iteration of the loop peforms the same
    // identical line of code, critters[i]->speak();
    // but object responds differently.

    for (int i = 0; i < 3; ++i) {
        critters[i]->speak();
    }
    return 0;
}


void Dog::speak() {
    cout << "Woof!" << endl;
}

void Cat::speak() {
    cout << "Meow!" << endl;
}

void Cow::speak() {
    cout << "Moo!" << endl;
}


