// Exercise 13.1.3.
// This exercise reports the size of the list.

#include <iostream>
#include <list>
#include <string>

using namespace std;

int main()
{
	string s;
	list<string> LS;
	list<string>::iterator iter;

	while (true) {
		cout << "Enter string (ENTER to exit): ";
		getline(cin, s);
		if (s.size() == 0) {
			break;
		}
		for (iter = LS.begin(); iter != LS.end() && s < *iter;
			iter++) {
		}
		LS.insert(iter, s);    // <- Here is where insertion is made!
	}
	for (iter = LS.begin(); iter != LS.end(); iter++) {
		cout << *iter << endl;
	}

        cout << "Size of the list is: " << LS.size() << endl;

	return 0;
}

