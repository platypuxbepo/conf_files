// Exercise 9.3.1
// This version of the writebin.cpp program writes out a
// record of info consists of: make (20 chars), model (20 chars),
// year (4 chars), and mileage (an int).
//

#include <iostream>
#include <fstream>
#include <cstring>    // Needed to support strlen
#include <cstdlib>    // Needed to support atoi

using namespace std;

int get_int(int default_value);

int main() {
    char filename[FILENAME_MAX];
    int n = 0;
    char model[20];
    char make[20];
    char year[5];
    int  mileage;

    int recsize = sizeof(model) + sizeof(make) +
           sizeof(year) + sizeof(int);
    
    cout << "Enter file name: ";
    cin.getline(filename, FILENAME_MAX);

    // Open file for binary write. 
    // NOTE THAT IT MUST ALSO BE OPENED FOR READING
    // (ios::in), OR ALL OLD DATA IS AUTOMATICALLY
    // OVERWRITTEN.   

    fstream  fbin(filename, ios::binary | ios::in | ios::out);
    if (!fbin) {
        cout << "Could not open " << filename << endl;
        return -1;
    }

    //  Get record number to write to.

    cout << "Enter file record number: ";
    n = get_int(0);

    // Get data from end user.

    cout << "Enter model: ";
    cin.getline(model, sizeof(model) - 1);
    cout << "Enter model: ";
    cin.getline(make, sizeof(make) - 1);
    cout << "Enter year: ";
    cin.getline(year, sizeof(year) - 1);
    cout << "Enter mileage: ";
    mileage = get_int(0);

    // Write data to the file.

    fbin.seekp(n * recsize);
    fbin.write(model, sizeof(model));
    fbin.write(make, sizeof(make));
    fbin.write(year, sizeof(year));
    fbin.write((char*)(&mileage), sizeof(int));
    fbin.close();
    return 0;
}

#define COL_WIDTH 80  // 80 is typical column width

// Get integer function
// Get an integer from keyboard; return default
//  value if user enters 0-length string.
//
int get_int(int default_value) {
    char s[COL_WIDTH+1];

    cin.getline(s, COL_WIDTH);
    if (strlen(s) == 0) {
         return default_value;
    }
    return atoi(s);
}




