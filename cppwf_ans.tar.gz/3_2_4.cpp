Exercise 3.2.4:

What are the minimum number of steps necessary to guarantee success in the
Guess-the-Number Game, assuming best strategy is used?

Note the following pattern:

1 move is sufficient to guarantee success for range size 1.

2 moves are sufficient to guarantee success for range size 3.
    (Because there's one spot on either side of the mid point.)

3 moves are sufficient to guarantee success for range size 7.
    (Because there are two areas of 3 on either side of mid point.)

4 moves are sufficient to guarantee success for range size 15.
    (Because there are two areas of 7 on either side of mid point.)

Note that if you add 1 to the sizes 1, 3, 7, 15, etc., you get powers of 2:
2, 4, 8, 16... Therefore, the solution is to add 1 to the size of the range,
and take the log-base-2 of this number, always rounding up:

     Ceiling(log-base-2(N + 1))

In C++ code, we can write this as:

     #include <cmath>  // Brings in support for ceil and log.

     int answer = ceil(log(n + 1)/log(2))


