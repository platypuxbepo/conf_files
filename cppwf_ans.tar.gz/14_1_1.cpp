// Exercise 14.1.1.
// This exercise tests out the PrizeManager class.

#include <iostream>
#include <string>
#include <ctime>
using namespace std;

class PrizeManager {
public:
    PrizeManager() {srand(time(NULL));}
    string get_good_prize();
    string get_bad_prize();
};

string PrizeManager::get_good_prize() {
    static const string prize_list[5] = {
       "YOUR BRAND NEW CAR!",
       "A BA-ZILLION DOLLARS!",
       "A EUROPEAN VACATION!",
       "A CONDO IN HAWAII!",
       "TEA WITH THE QUEEN OF ENGLAND!"
     };
     return prize_list[rand() % 5];
}

string PrizeManager::get_bad_prize() {
    static const string prize_list[8] = {
       "two week's supply of Spam.",
       "a crate of rotting fish heads.",
       "a visit from a circus clown.",
       "two weeks at a clown college.",
       "a ten-year-old VCR player.",
       "a lesson from a mime.",
       "psychoanalysis from a clown.",
       "a tour of the city dump."
     };     
     return prize_list[rand() % 8];

}


int main()
{
    int cmd = 0;

    PrizeManager pr_mgr;
    while (true) {
         cout << "Enter command: 1 - good prize, 2 - bad prize, ";
         cout << "3 - exit: ";
         cin >> cmd;
         if (cmd == 1) {
             cout << pr_mgr.get_good_prize() << endl;
         } else if (cmd == 2) {
             cout << pr_mgr.get_bad_prize() << endl;
         } else {
             break;
         }
    }
    return 0;
}


