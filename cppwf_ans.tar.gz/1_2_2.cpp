// Exercise 1.2.2

#include <iostream>
using namespace std;

int main()
{
    cout << "I am Blaxxon," << endl << endl;
    cout << "the cosmic computer." << endl << endl;
    cout << "Fear me!" << endl << endl;
    return 0;
}