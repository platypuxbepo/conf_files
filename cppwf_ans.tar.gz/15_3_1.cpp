// Exercise 15.3.1
// This version of the program uses the Eval::rank_hand 
// function to return payout information via a pointer arg.
//

#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <vector>
using namespace std;

int stake = 100;      // Player initial stake.

class Card {
public:
    Card() {}
    Card(int r, int s) { rank = r; suit = s; }
    int rank;
    int suit;
    string display();
};

string Card::display() {
    static const string aRanks[] = {" 2", " 3", " 4",
      " 5", " 6", " 7", " 8", " 9", "10", " J", " Q",
      " K", " A" };
    static const string aSuits[] = {
      "clubs", "diamonds", "hearts", "spades" };
    return aRanks[rank] + " of " + aSuits[suit] + ".";
}


class Deck {
public:
    Deck();
    Card deal_a_card();
private:
    int cards[52];
    int iCard;
    void shuffle();
};

Deck::Deck() {
    srand(time(NULL));
    for (int i = 0; i < 52; ++i) {
        cards[i] = i;
    }
    shuffle();
}

void Deck::shuffle() {
    iCard = 0;
    for (int i = 51; i > 0; --i) {
        int j = rand() % (i + 1);
        int temp = cards[i];
        cards[i] = cards[j];
        cards[j] = temp;
    }
}

Card Deck::deal_a_card() {
    if (iCard > 51) {
        cout << endl << "RESHUFFLING..." << endl;
        shuffle();
    }
    int r = cards[iCard] % 13;
    int s = cards[iCard++] / 13;
    return Card(r, s);
}


class Eval {
public:
    Eval(Card* pCards);
    string rank_hand(int *p_to_payout);
private:
    int rankCounts[13];
    int suitCounts[4];
    int has_reps(int n);
    bool is_straight();
    bool verify_straight(int n);
    bool is_flush();
    bool is_two_pair();
};

Eval::Eval(Card* pCards) {
    for (int i = 0; i < 13; ++i) {  // Clear arrays
        rankCounts[i] = 0;
    }
    for (int i = 0; i < 4; ++i) { 
        suitCounts[i] = 0;
    }
    for(int i = 0; i < 5; ++i) {    // Init arrays
        int r = pCards[i].rank;
        int s = pCards[i].suit;
        ++rankCounts[r];
        ++suitCounts[s];
    }
}

string Eval::rank_hand(int *p_to_payout) {
    string s;
    if (is_straight() && is_flush()) {
        if (rankCounts[12] && rankCounts[11]) {  // A&K
          s = "You have a ROYAL FLUSH! PAYOUT = 800";
          *p_to_payout = 800;
        }else {
          s = "You have a STRAIGHT FLUSH! PAYOUT = 50";
          *p_to_payout = 50;
        }
    } else if (has_reps(4)) {
        s = "You have FOUR OF A KIND!  PAYOUT = 25";
        *p_to_payout = 25;
    } else if (has_reps(3) && has_reps(2)) {
        s = "You have a FULL HOUSE!  PAYOUT = 9";
        *p_to_payout = 9;
    } else if (is_flush()) {
        s = "You have a FLUSH!  PAYOUT = 6";
        *p_to_payout = 6;
    } else if (is_straight()) {
        s = "You have a STRAIGHT!  PAYOUT = 4";
        *p_to_payout = 4;
    } else if (has_reps(3)) {
        s = "You have three of a kind.  PAYOUT = 3";
        *p_to_payout = 3;
    } else if (is_two_pair()) {
        s = "You have two pair.  PAYOUT = 2";
        *p_to_payout = 2;
    } else if (has_reps(2)) {
        s = "You have a pair.  PAYOUT = 1";
        *p_to_payout = 1;
    } else {
        s ="You have no pair.  PAYOUT = 0.";
        *p_to_payout = 0;
    }
    return s;
}

// Has reps function.
// Return true if any rank is repeated the
//   the specified number of times.

int Eval::has_reps(int n) {
    for(int i = 0; i < 13; ++i) {
        if (rankCounts[i] == n) {
            return true;
        }
    }
    return false;
}

// Is straight function.
// Look for first "singleton" in the ranks,
//   and then verify if it begins a straight.

bool Eval::is_straight() {
    for (int i = 0; i < 8; ++i) {
        if (rankCounts[i] == 1) {
            return verify_straight(i);
        }
    }
    return false;
}

bool Eval::verify_straight(int n) {
    for (int i = n + 1; i < n + 5; ++i) {
        if (rankCounts[i] != 1) {
            return false;
        }
    }
    return true;
}

bool Eval::is_flush() {
    for(int i = 0; i < 4; ++i) {
        if (suitCounts[i] == 5) {
            return true;
        }
    }
    return false;
}

bool Eval::is_two_pair() {
    int n = 0;
    for(int i = 0; i < 13; ++i) {
        if (rankCounts[i] == 2) {
            ++n;
        }
    }
    return n == 2;
}





Deck my_deck;
Card aCards[5];
bool aFlags[5];
vector<int> selVec;

void play_game();
bool draw();

int main()
{
    string s;
    while (true) {
        play_game();
        cout << "Play again? (Y or N): ";
        getline(cin, s);
        if (s[0] == 'N' || s[0] == 'n') {
            break;
        }
    }
    return 0;
}

void play_game() {
     for (int i = 0; i < 5; ++i) {
         aCards[i] = my_deck.deal_a_card();
         aFlags[i] = false;
         cout << i + 1 << ". ";
         cout << aCards[i].display() << endl;
     }
     cout << endl;

     // Draw new cards, and then re-display

     if (draw()) {
         for (int i = 0; i < 5; ++i) {
             cout << i + 1 << ". ";
             cout << aCards[i].display();
             if (aFlags[i]) {
                 cout << " *";
             }
             cout << endl;
         }
         cout << endl;
     }
     Eval my_eval(aCards);

     int pay_info;
     cout << my_eval.rank_hand(&pay_info) << endl;
     stake += (pay_info - 1);
     cout << "Your stake is now " << stake << endl;
}

bool draw() {
    string sInput;
    selVec.clear();
    cout << "Input #'s of cards to redraw: ";
    getline(cin, sInput);
    if (sInput.size() == 0) {
        return false;
    }
    // Read input string, adding an
    //  element to selVec for each digit read.

    for (int i = 0; i < sInput.size(); ++i) {
        int n = sInput[i] - '0';
        if (n >= 1 && n <= 5) {
            selVec.push_back(n - 1);
        }
    }
    // For each number (0-4) in selVec, redraw
    //  the corresponding card.

    for (int i = 0; i < selVec.size(); ++i) {
        int j = selVec[i];
        aCards[j] = my_deck.deal_a_card();
        aFlags[j] = true;
    }
    return true;
}

