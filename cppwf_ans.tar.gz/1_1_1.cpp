// Exercise 1.1.1

#include <iostream>
using namespace std;

int main()
{
    cout << "Get with the program! ";
    return 0;
}