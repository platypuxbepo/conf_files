// Exercise 5.3.2
// This program calls recursive triangle function.

#include <iostream>

using namespace std;

int triangle(int n);

int main()
{
    while (true) {
         int n = 0;
         cout << "Enter a number (0 to exit): ";
         cin >> n;
         if (n == 0) {
              break;
         }
         cout << "triangle(" << n << ") = ";
         cout << triangle(n) << endl;
    }
    return 0;
}

// Recursive version of triangle().

int triangle(int n) {
    if (n <= 1) {
         return 1;
    } else {
         return n + triangle(n - 1);
    }
}
