// Exercise 10.1.4
// This example tests and displays an array of 
// seven Point objects.
//

#include <iostream>
using namespace std;

class Point {
private:            // Data members (private)
    int x, y;
public:              // Member functions
    void set(int new_x, int new_y);
    int get_x();
    int get_y();
};

int main() {
    Point array_of_points[7];

    // Prompt user for x, y values of each point.

    for(int i = 0; i < 7; ++i) {
        int x, y;
        cout << "For point #" << i << "..." << endl;
        cout << "Enter x coord: ";
        cin >> x;
        cout << "Enter y coord: ";
        cin >> y;
        array_of_points[i].set(x, y);         
    }

    // Print out values of each point.
    
    for(int i = 0; i < 7; ++i) {
        cout << "Value of array_of_points[" << i << "]";
        cout << " is " << array_of_points[i].get_x() << ", ";
        cout << array_of_points[i].get_y() << "." << endl;
    }

    return 0;
}

void Point::set(int new_x, int new_y) {
    if (new_x < 0)
        new_x *= -1;
    if (new_y < 0)
        new_y *= -1;
    x = new_x;
    y = new_y;
}

int Point::get_x() {
    return x;
}

int Point::get_y() {
    return y;
}

