// Exercise 6.3.2
// This version of the program supports numbers in the 1 to 9
// range, but gets rid of the extra space that would be 
// printed for such numbers.

#include <iostream>
#include <string>  // REMEMBER TO INCLUDE THIS!

using namespace std;

string tens_names[ ] = {"", "", "twenty", "thirty", "forty",
   "fifty", "sixty", "seventy", "eighty", "ninety" };

string units_names[ ] = {"", "one", "two", "three", "four",
   "five", "six", "seven", "eight", "nine" };

int main()
{
    int  n = 0;

    cout << "Enter a number from 1 to 9 or 20 to 99: ";
    cin >> n;
    
    while ((n < 20 || n > 99) && (n < 1 || n > 9)) {
        cout << "Number out of range. Re-enter: ";
        cin >> n;
    }

    int tens_digits = n / 10;
    int units_digits = n % 10;
    cout << "The number you entered was ";
    if (n > 9) {
        cout << tens_names[tens_digits] << " ";
    }
    cout << units_names[units_digits] << endl;
    return 0;
}

