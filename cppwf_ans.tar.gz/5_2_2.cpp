// Exercise 5.2.2
// This version of the program tests all numbers for
// prime-ness, from 2 to 20.

#include <iostream>
#include <cmath>      // Include because sqrt is called.

using namespace std;

// Function must be declared before being used.
bool prime(int n);

int main()
{
   for(int i = 2; i <= 20; ++i) {
      if (prime(i)) {      // Call prime(i)
         cout << i << " is prime" << endl;
      } else {
         cout << i << " is not prime" << endl;
      }
   }
   return 0;
}

// Prime-number function. Test divisors from
//  2 to sqrt of n. Return false if a divisor
//  found; otherwise, return true.
bool prime(int n) {

    double sqrt_of_n = sqrt(n);

    for (int i = 2; i <= sqrt_of_n; ++i) {
       if (n % i == 0) {   // If i divides n evenly,
          return false;    //  n is not prime.
       }
    }
    return true;   // If no divisor found, n is prime.
}
                   
