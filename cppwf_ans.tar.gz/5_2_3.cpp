// Exercise 5.2.3
// This program prints the first number
// greater than 1,000,000,000 that is prime.

#include <iostream>
#include <cmath>      // Include because sqrt is called.

using namespace std;

// Function must be declared before being used.
bool prime(int n);

int main()
{
   int n = 1000000000;
   while (! prime(n)) {
       ++n;
   }
   cout << "The first prime bigger than a billion";
   cout << " is: " << n << endl;
   return 0;
}

// Prime-number function. Test divisors from
//  2 to sqrt of n. Return false if a divisor
//  found; otherwise, return true.
bool prime(int n) {

    double sqrt_of_n = sqrt(n);

    for (int i = 2; i <= sqrt_of_n; ++i) {
       if (n % i == 0) {   // If i divides n evenly,
          return false;    //  n is not prime.
       }
    }
    return true;   // If no divisor found, n is prime.
}
                   
