// Exercise 12.1.7
// This exercise uses an iterative insert() function.

#include <iostream>
#include <string>

using namespace std;

class Bnode {
public:
    string val;
    Bnode* pLeft;
    Bnode* pRight;
    Bnode(string s) { val = s; pLeft = pRight = nullptr; }
};

class Btree {
public:
    Btree() { root = NULL; }
    void insert(string s);
    void print() { print_sub(root); }

private:
    Bnode* root;
    void   print_sub(Bnode* p);
};


int main() {
    Btree my_tree;

    string sPrompt = "Enter a name (ENTER when done): ";
    string sInput = "";

    while (true) {
        cout << sPrompt;
        getline(cin, sInput);
        if (sInput.size() == 0) {
            break;
        }
        my_tree.insert(sInput);
    }
    cout << "Here are the names, in order." << endl;
    my_tree.print();
    return 0;
}

// Interative version of insert().
// If root is null, then create new node and it
// becomes the root. Otherwise, search for proper
// insertion point and then create the node. If
// duplicate is found, don't insert new node.
//
void Btree::insert(string s) {
    Bnode* p = root;

    if (!p) {
         root = new Bnode(s);
         return;
    }
    while(true) {
        if (s < p->val) {
            if (p->pLeft) {
                p = p->pLeft;
            } else {
                p->pLeft = new Bnode(s);
                return;
            }            
        } else if (s > p->val) {
            if (p->pRight) {
                p = p->pRight;
            } else {
                p->pRight = new Bnode(s);
                return; 
            }                       
        } else {
           return;  // Do nothing if match found.
        }  // end if-else
    }   // end while
}  // end function



void Btree::print_sub(Bnode* p) {
    if (p) {
        print_sub(p->pLeft);
        cout << p->val << endl;
        print_sub(p->pRight);
    }
}


