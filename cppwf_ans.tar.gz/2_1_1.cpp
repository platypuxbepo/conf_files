// Exercise 2.1.1.
// This program tests for divisibility by 7 rather than 2.

#include <iostream>
using namespace std;

int main()
{
    int  n;

    // Get a number n from the keyboard.

    cout << "Enter a number and press ENTER: ";
    cin >> n;


    // Get remainder after dividing by 7.

    if (n % 7 == 0) {
        cout << "The number is divisible by 7.";
    } else {
        cout << "The number is NOT divisible by 7.";
    }
    cout << endl;
    return 0;
}




