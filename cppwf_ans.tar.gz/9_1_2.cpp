// Exercise 9.1.2
// This version of writetxt.cpp lets user enter repeated
// lines of text to write, until they enter a zero-length 
// string.
//

#include <iostream>
#include <fstream>

using namespace std;

#define LINEMAX 256

char strLine[LINEMAX + 1];

int main() {
    char filename[FILENAME_MAX + 1];

    cout << "Enter a file name and press ENTER: ";
    cin.getline(filename, FILENAME_MAX);
    
    ofstream file_out(filename);
    if (! file_out) {
        cout << filename << " could not be opened.";
        cout << endl;
        return -1;
    }
    cout << filename << " was opened." << endl;

    while (true) {
        cout << "Enter text: ";
        cin.getline(strLine, LINEMAX);
        if (strlen(strLine) == 0) {
             break;
        }
        file_out << strLine << endl;
    }

    return 0;
}

