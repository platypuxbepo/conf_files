// Exercise 7.4.1
// This version of the program uses pointer reference to 
// print out all the values in the array.
//

#include <iostream>

using namespace std;

void zero_out_array(int *arr, int n);

int a[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

int main() {

    zero_out_array(a, 10);

    // Print out all the elements of the array.
    // This is the part revised to use direct
    // pointer reference.

    for (int *p = a; p < a + 10; ++p) {
        cout << *p << "  ";
    }
    cout << endl;
    return 0;
}

// Zero-out-array function.
// Assign 0 to all elements of an int array of size n.
//
void zero_out_array(int *p, int n) {
    while (n-- > 0) {  // Do n times:
      *p = 0;          //  Assign 0 to element pointed
                       //    to by p.
      ++p;             //  Point to next element.
    }
}
