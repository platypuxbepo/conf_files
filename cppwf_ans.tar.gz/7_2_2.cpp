// Exercise 7.2.2
// This program uses a pointer argument to call
// a temperature-conversion function. 

#include <iostream>
using namespace std;

void convert_it(double *p);  // Take a Cent temperature, and
                             // convert it to Fahrenheit.

int main()
{
   double cent = 0.0;        // Centigrade temperature.

   cout << "Enter a Cent. temperature: ";
   cin >> cent;

   convert_it(&cent);      // Pass address of cent.
 
   cout << "Val. of temperature after conversion: " << cent << endl;
   return 0;
}

void convert_it(int *p) {
   *p = (*p * 1.8) + 32.0;
}

