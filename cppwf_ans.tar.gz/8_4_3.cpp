// Exercise 8.4.3
// This version of the tokenize program recognizes
// ampersands (&) as delimiters. This involves altering
// only two lines of code, as it is only necessary to 
// add "&" to delimiter string in calls to strtok.

#include <iostream>
#include <cstring>

using namespace std;

int main()
{
    char the_string[81], *p;
    
    cout << "Input a string to parse: ";
    cin.getline(the_string, 81);
    p = strtok(the_string, "&, ");     // <- altered
    while (p != nullptr) {
          cout << p << endl;
          p = strtok(nullptr, "&, ");  // <- altered
    }      
    return 0;
}




