// Exercise 7.2.1
// This program uses pointers to successfully call
// a triple_it() function. 

#include <iostream>
using namespace std;

void triple_it(int *p);

int main()
{
   int n = 15;

   cout << "Val. of n before tripling: " << n << endl;

   triple_it(&n);      // Pass address of n.
 
   cout << "Val. of n after tripling: " << n << endl;
   return 0;
}

void triple_it(int *p) {
   *p = *p * 3;
}