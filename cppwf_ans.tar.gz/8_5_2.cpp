// Exercise 8.5.2
// This is another string-building program using the STL
// string class.
//

#include <iostream>
#include <string>    // Include support for string class.
using namespace std;

int main()
{
    string str1, str2, str3;
    string name, breed, age;

    // Get three strings from the user.

    cout << "Enter dog's name and press ENTER: ";
    getline(cin, name);
    cout << "Enter breed and press ENTER: ";
    getline(cin, breed);
    cout << "Enter dog's age and press ENTER: ";
    getline(cin, age);

    // Build the output string(s), and then print them.
    // Note that there is no "+=" operator.

    str1 = "Once there was a dog named " + name + ". ";
    str1 = str1 + name + " was a very nice dog, " + age + " years old.";
    str2 = "The breed of " + name + " was " + breed + ".";
    str3 = "One day a hurricane came, but " + name;
    str3 = str3 + " went for help and saved the town.";

    cout << str1 << endl << str2 << endl << str3 << endl;

    return 0;
}
