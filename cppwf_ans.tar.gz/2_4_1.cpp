// Exercise 2.4.1
// This program optimizes the code by testing for the
// the square root of n just once.

#include <iostream>
#include <cmath>
using namespace std;

int main() {
    int  n = 0;  // Number to test for prime-ness
    int  i = 2;  // Loop counter
    bool is_prime = true;   // Boolean flag...
                            // Assume true for now.

    // Get a number from the keyboard.

    cout << "Enter a number and press ENTER: ";
    cin >> n;
    
    // Test for prime by checking for divisibility
    //  by all whole numbers from 2 to sqrt(n).

    double sqrt_of_n = sqrt(n);  // Here is the one call to sqrt.

    while (i <= sqrt_of_n) {   
        if (n % i == 0) {      //  If i divides n,
            is_prime = false;  //    n is not prime.
        }
        ++i;                   //  Add 1 to i.
    }

    // Print results

    if (is_prime) {
        cout << "Number is prime." << endl;
    } else {
        cout << "Number is not prime." << endl;
    }
    return 0;
}


