// Exercise 7.3.3
// This version of the sort program uses a Bubble Sort
// instead of a selection sort.
//

#include <iostream>
using namespace std;

void sort(int n);
void swap(int *p1, int *p2);

int a[10];   

int main ()
{
    for (int i = 0; i < 10; ++i) {
        cout << "Enter array element #" << i << ": ";
        cin >> a[i];
    }
    sort(10);

    cout << "Here is the array, sorted:" << endl;
    for (int i = 0; i < 10; ++i) {
        cout << a[i] << "  ";
    }
    cout << endl;
    return 0;
}

// Sort function: sort array named a with n elements.
// This is the Bubble Sort algorithm.
//
void sort (int n) {
    int low = 0;
    bool in_order = true;

	for (int i = n - 1; i > 0; --i) {
		in_order = true;
		for (int j = 0; j < i; ++j) {
			if (a[j + 1] < a[j]) {
				swap(&a[j + 1], &a[j]);
				in_order = false;
			}
		}
		if (in_order) {
			break;
		}
	}
}

// Swap function.
// Swap the values pointed to by p1 and p2.
//
void swap(int *p1, int *p2) {
    int temp = *p1;
    *p1 = *p2;
    *p2 = temp;
}

