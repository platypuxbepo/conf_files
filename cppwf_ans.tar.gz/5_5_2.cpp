// Exercise 5.5.2

// This version of the tower puzzler solver calls another

// function, exec_move(), to print a longer move message.
// 

#include <iostream>
using namespace std;
void move_rings(int n, int src, int dest, int other);

void exec_move(int src, int dest);

int main()
{
    int n = 0; 

    // The next lines prompt for size of stack.

    cout << "Enter the size of the stack: ";
    cin >> n;
    while (n <= 0) {
         cout << "Sorry, n must be > 0. Re-enter: ";
         cin >> n;
    }
    
    move_rings(n, 1, 3, 2); // Move stack 1 to stack 3
    cout << endl;
    return 0;
}

void move_rings(int n, int src, int dest, int other) {
    if (n == 1) {
        exec_move(src, dest);
    } else {
        move_rings(n - 1, src, other, dest);
        exec_move(src, dest);
        move_rings(n - 1, other, dest, src);
    }
}

void exec_move(int src, int dest) {
    cout << "Move the top ring from ";

    cout << src << " to " << dest << endl;
}
