// Exercise 5.4.2
// This version of the GCF (Greatest Common Factor) 
// function uses iteration rather than recursion.

#include <iostream>
using namespace std;
int gcf(int a, int b);

int main()
{
    int a = 0, b = 0; // Inputs to GCF.

    cout << "Enter a: ";
    cin >> a;
    cout << "Enter b: ";
    cin >> b;
    cout << "GCF = " << gcf(a, b) << endl;
    return 0;
}

// CGF function, iterative version. The loop]
// continues as long as b is not equal to 0.
// Each time through the cycle, a and b must
// be replaced with b and a % b, respectively.

int gcf(int a, int b) {
    while (b > 0) {
        int temp = a;
        a = b;
        b = temp % b;
     }
     return a;
}

