// Exercise 2.5.2
// This program enables subtracting any number from 1 to n, where
// n is a number stipulated at the beginning of the game.
//

#include <iostream>

using namespace std;

int main()
{
    int total = 0, n = 0;
    int max_n = 0;       // This is the limit of moves that
                         // may be entered.
    
    while (true) {
         cout << "Welcome to NIM. Pick a starting total > 0: ";
         cin >> total;
         if (total > 0) {
              break;
         }
         cout << "Total must be great than 0!" << endl;
    }

    while (true) {
         cout << "Pick a maximum amount to subtract by: ";
         cin >> max_n;
         if (max_n > 1) {
              break;
         }
         cout << "This number must be greater than 1." << endl;
    }

    while (true) {

         // Pick best response and print results.
         // This ideal result is based on comparing total
         //  to max_n and performing remainder division (%).

         int diff = total % (max_n + 1);
         if (diff > 0) {
              total = total - diff;
              cout << "I am subtracting " << diff << endl;
         } else {
              total = total - 1;
              cout << "I am subtracting 1" << endl;
         }
         cout << "New total is " << total << endl;
         if (total <= 0) {
              cout << "I win!" << endl;
              break;
         }

         // Get user's response; must be 1 or 2.

         cout << "Enter num to subtract (1 or 2): ";
         cin >> n;
         while (n < 1 || n > max_n) {
             cout << "Input must be in range 1 to " << diff;
             cout << endl;
             cout << "Re-enter: ";
             cin >> n;
         }
         total = total - n;
         cout << "New total is " << total << endl;
         if (total <= 0) {
              cout << "You win!" << endl;
              break;
         }
    }
    return 0;
}

