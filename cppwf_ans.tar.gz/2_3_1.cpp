// Exercise 2.3.1
// This program tests whether a number entered by user
// is in the range 0 to 100, inclusive.

#include <iostream>
using namespace std;

int main() {
    int  n;

    cout << "Enter a number and press ENTER: ";
    cin >> n;

    if (n >= 0 && n <= 100) { 
        cout << "Number is in range 0 to 100." << endl;
    } else {
        cout << "Number is NOT in range." << endl;
    }
    return 0;
}


