// Exercise 8.4.1
// This version of the tokenize program reports
// how many tokens it found.

#include <iostream>
#include <cstring>

using namespace std;

int main()
{
    int n = 0;     // This will store number of tokens.

    char the_string[81], *p;
    
    cout << "Input a string to parse: ";
    cin.getline(the_string, 81);
    p = strtok(the_string, ", ");
    while (p != nullptr) {
          ++n;     // Token found, so increment n.
          cout << p << endl;
          p = strtok(nullptr, ", ");
    } 
    cout << "Number of tokens is: " << n << endl;     
    return 0;
}



