// Exercise 6.3.4
// This version of the program supports the full range 1 to 99,
// by adding teen names and adding appropriate conditions. It
// also supports numbers ranging up to 999!

#include <iostream>
#include <string>  // REMEMBER TO INCLUDE THIS!

using namespace std;

string tens_names[ ] = {"", "", "twenty", "thirty", "forty",
   "fifty", "sixty", "seventy", "eighty", "ninety" };

string units_names[ ] = {"", "one", "two", "three", "four",
   "five", "six", "seven", "eight", "nine" };

string teen_names[ ] = {"ten", "eleven", "twelve", "thirteen",
   "fourteen", "fifteen", "sixteen", "seventeen", "eighteen",
   "nineteen" };

int main()
{
    int  n = 0;

    cout << "Enter a number from 1 to 999: ";
    cin >> n;
    
    while (n < 1 || n > 999) {
        cout << "Number out of range. Re-enter: ";
        cin >> n;
    }

    int hundreds_digits = n / 100;
    int remainder_from_100 = n % 100;
    int tens_digits = remainder_from_100 / 10;
    int units_digits = remainder_from_100 % 10;
    cout << "The number you entered was ";
    if (n > 99) {
        cout << units_names[hundreds_digits] << " hundred ";
    }
    n = remainder_from_100;
    if (n > 9 && n < 20) {
        cout << teen_names[units_digits] << endl;
    } else {
        if (n > 19) {
            cout << tens_names[tens_digits] << " ";
        }
        cout << units_names[units_digits];
    }
    cout << endl;
    return 0;
}

