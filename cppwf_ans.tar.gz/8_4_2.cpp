// Exercise 8.4.2
// This version of the tokenize program prints tokens
// separated by ampersands. Note that in this case, there
// are only two new or altered lines of code.

#include <iostream>
#include <cstring>

using namespace std;

int main()
{
    char the_string[81], *p;
    
    cout << "Input a string to parse: ";
    cin.getline(the_string, 81);
    p = strtok(the_string, ", ");
    while (p != nullptr) {
          cout << p << "&";   // <- New line here.
          p = strtok(nullptr, ", ");
    } 
    cout << endl;             // <- and here.     
    return 0;
}


