// Exercise 6.1.3
// This version of the array printing program prompts
// for seven integer values.

#include <iostream>
using namespace std;

int main()
{
    int sum = 0;  // Running total kept here.

    int scores[7];  // Uninitialized array, size 7

    // This loop prompts for the 7 values.

    for(int i = 0; i < 7; ++i) {
        cout << "Enter value of element " << i << ": ";
        cin >> scores[i];
    }

    // This loop prints out each element and keeps
    // a running total.

    for(int i = 0; i < 7; ++i) {
        cout << scores[i] << "  ";
        sum += i;
    }
    cout << endl << "The sum is: " << sum << endl;
    return 0;
}


