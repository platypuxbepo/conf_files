// Exercise 8.6.1
// This version of get_num calls the function, specifying a
// default value to return if the user presses ENTER with no
// input.
//

#include <iostream>
#include <string>    // Include support for string class.
using namespace std;

bool get_next_num(int *p, int def_val);

int main()
{
     int sum = 0;
     int n = 0;

     while (get_next_num(&n, 0)) {
          sum += n;
     }
     cout << "The total is: " << sum << endl;
     return 0;
}

bool get_next_num(int *p, int def_val) {
     string input_line;
     cout << "Enter num (press ENTER to quit): ";
     getline(cin, input_line);
     if (input_line.size() == 0) {
          *p = def_val;     // <- Note new line here.
          return false;
     }
     *p = stoi(input_line);
     return true;
}

