// Exercise 2.2.2
// This program counts down from a number n.

#include <iostream>
using namespace std;

int main()
{
    int  i, n;

    // Get number from the keyboard and initialize i.

    cout << "Enter a number and press ENTER: ";
    cin >> n;
    i = n;

    while (i > 0) {     // While i is greater than zero,
        cout << i << " ";   //   Print i,
        i = i - 1;          //   Subtract 1 from i.
    }
    cout << endl;
    return 0;
}


