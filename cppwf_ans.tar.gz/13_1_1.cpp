// Exercise 13.1.1
// This exercise uses a continually sorted list.

#include <iostream>
#include <list>
#include <string>

using namespace std;

int main()
{
	string s;
	list<string> LS;
	list<string>::iterator iter;

	while (true) {
		cout << "Enter string (ENTER to exit): ";
		getline(cin, s);
		if (s.size() == 0) {
			break;
		}
		for (iter = LS.begin(); iter != LS.end() && s > *iter;
			iter++) {
		}
		LS.insert(iter, s);    // <- Here is where insertion is made!
	}
	for (iter = LS.begin(); iter != LS.end(); iter++) {
		cout << *iter << endl;
	}

	return 0;
}

