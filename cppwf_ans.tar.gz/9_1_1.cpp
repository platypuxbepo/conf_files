// Exercise 9.1.1
// This version of writetxt.cpp prompts for pathname
// and filename separately, then concatentates them
// together.
//

#include <iostream>
#include <fstream>
#include <cstring>  // Needed to support strcat.

using namespace std;

int main() {
    char pathname[FILENAME_MAX + 1];
    char filename[FILENAME_MAX + 1];

    cout << "Enter a path name and press ENTER: ";
    cin.getline(pathname, FILENAME_MAX);
    cout << "Enter a file name and press ENTER: ";
    cin.getline(filename, FILENAME_MAX);
    strcat(pathname, filename);
    
    ofstream file_out(pathname);
    if (! file_out) {
        cout << filename << " could not be opened.";
        cout << endl;
        return -1;
    }
    cout << pathname << " was opened." << endl;
    file_out << "I read the" << endl;
    file_out << "news today," << endl;
    file_out << "ooh boy.";
    file_out.close();
    return 0;
}


