// Exercise 3.2.3.
// This program takes the point of view of the player in the
// Guess-the-Number Game, employing best strategy. The user
// must answer truthfully or the program will fail!

#include <iostream>
using namespace std;

int main()
{
     cout << "Guess a number between 1 and 50 ";
     cout << "and remember this number." << endl;
     int lo = 1;
     int hi = 50;
     int cmd = 0;

     while (true) {
          int guess = (lo + hi) / 2;
          cout << "My guess is " << guess << "." << endl;
          cout << "Tell me how I did. 1 = guess too high. ";
          cout << "2 = guess too low, 3 = success: ";
          cin >> cmd;
          while (cmd < 1 || cmd > 3) {
               cout << "Out of range. Re-enter: ";
               cin >> cmd;
          }
          if (cmd == 3) {
               cout << "Great! Fun playing with you!" << endl;
               break;
          } else if (cmd == 1) {      // Guess too high; lower it.
               hi = guess - 1;
          } else {                  // Guess too low; raise it.
               lo = guess + 1;
          }
      }
      return 0;
}
