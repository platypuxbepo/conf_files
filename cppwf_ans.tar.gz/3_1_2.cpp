// Exercise 3.1.2
// This program uses while without do or break.
//

#include <iostream>

using namespace std;

int main()
{
    int  sum = 0;
    int  n = 1;     // Artificially start n > 0.

    while (n > 0) {
        cout << "Enter a number (0 for exit): ";
        cin >> n;   // n set by user for first time HERE.
        sum += n;
    }
    cout << "The sum is " << sum << endl;
    return 0;
}

