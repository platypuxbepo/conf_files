// Exercise 6.4.3
// This version of the dealer program simulates a
// six deck "shoe" of 312 cards. 

#include <iostream>
#include <string>     // Needed for string class.
#include <cstdlib>    // Needed for randomization.
#include <ctime>

using namespace std;

int deck[312];

string card_names[ ] = {"A", "2", "3", "4", "5", "6",
   "7", "8", "9", "10", "J", "Q", "K" };


// New array is declared to handle suit names...

string suit_names[ ] = {"clubs", "diamonds", "hearts",
   "spades" };


void swap_cards(int i, int j);
int rand0_to_N(int n);

int main()
{
    srand(time(NULL));  // Set random seed.

    // Initialize deck 0, 1, 2, 3... 51

    for (int i = 0; i < 312; ++i) {
        deck[i] = i;
    }

    // Shuffle deck.

    for (int i = 311; i > 0; --i) {
        int j = rand0_to_N(i);
        swap_cards(i, j);
    }

    // Deal 5 cards.

    for (int i = 0; i < 5; ++i) {
        int j = deck[i] % 13;
        int k = (deck[i] % 52) / 13;  // <- New line here!
        cout << card_names[j] << " of ";
        cout << suit_names[k] << endl;
    }
    cout << endl;
    return 0;
}

//
void swap_cards(int i, int j) {
    int temp = deck[i];
    deck[i] = deck[j];
    deck[j] = temp;
}

//
int rand0_to_N(int n) {
    return rand() % (n + 1);
}

