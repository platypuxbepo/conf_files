// Exercise 15.2.5
// This version of the Poker program does not redraw a card
// more than once, no matter what the user's input it. This
// is accomplished by checking the aFlags array (at bottom
// of code) before doing a redraw.
//

#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <vector>
using namespace std;

class Card {
public:
    Card() {}
    Card(int r, int s) { rank = r; suit = s; }
    int rank;
    int suit;
    string display();
};

string Card::display() {
    static const string aRanks[] = { " 2", " 3", " 4",
        " 5", " 6", " 7", " 8", " 9", "10", " J", " Q",
        " K", " A" };
    static const string aSuits[] = {
        "clubs", "diamonds", "hearts", "spades" };
    return aRanks[rank] + " of " + aSuits[suit] + ".";
}


class Deck {
public:
    Deck();
    Card deal_a_card();
private:
    int cards[52];
    int iCard;
    void shuffle();
};

Deck::Deck() {
    srand(time(NULL));
    for (int i = 0; i < 52; ++i) {
        cards[i] = i;
    }
    shuffle();
}

void Deck::shuffle() {
    iCard = 0;
    for (int i = 51; i > 0; --i) {
        int j = rand() % (i + 1);
        int temp = cards[i];
        cards[i] = cards[j];
        cards[j] = temp;
    }
}

Card Deck::deal_a_card() {
    if (iCard > 51) {
        cout << endl << "RESHUFFLING..." << endl;
        shuffle();
    }
    int r = cards[iCard] % 13;
    int s = cards[iCard++] / 13;
    return Card(r, s);
}

Deck my_deck;
Card aCards[5];
bool aFlags[5];
vector<int> selVec;

void play_game();
bool draw();

int main() {
    string s;
    while (true) {
        play_game();
        cout << "Play again? (Y or N): ";
        getline(cin, s);
        if (s[0] == 'N' || s[0] == 'n') {
            break;
        }
    }
    return 0;
}

void play_game() {
    for (int i = 0; i < 5; ++i) {
        aCards[i] = my_deck.deal_a_card();
        aFlags[i] = false;
        cout << i + 1 << ". ";
        cout << aCards[i].display() << endl;
    }
    cout << endl;

    // Draw new cards, and then re-display

    if (draw()) {
        for (int i = 0; i < 5; ++i) {
            cout << i + 1 << ". ";
            cout << aCards[i].display();
            if (aFlags[i]) {   
                cout << " *";
            }
            cout << endl;
	}
        cout << endl;
    }
}

bool draw() {
    string sInput;
    selVec.clear();
    cout << "Input #'s of cards to redraw: ";
    getline(cin, sInput);
    if (sInput.size() == 0) {
        return false;
    }
    // Read input string, adding an
    //  element to selVec for each digit read.

    for (int i = 0; i < sInput.size(); ++i) {
        int n = sInput[i] - '0';
        if (n >= 1 && n <= 5) {
            selVec.push_back(n - 1);
        }
    }
    // For each number (0-4) in selVec, redraw
    //  the corresponding card.

    for (int i = 0; i < selVec.size(); ++i) {
        int j = selVec[i];  // Select a card
        if (!aFlags[j]) {   // <- HERE IS THE NEW CODE!
            aCards[j] = my_deck.deal_a_card();
            aFlags[j] = true;
        }
    }
    return true;
}
