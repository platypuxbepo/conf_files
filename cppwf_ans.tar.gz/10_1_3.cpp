// Exercise 10.1.3
// This example tests and displays five Point
// objects.
//

#include <iostream>
using namespace std;

class Point {
private:            // Data members (private)
    int x, y;
public:              // Member functions
    void set(int new_x, int new_y);
    int get_x();
    int get_y();
};

int main() {
    Point ptA, ptB, ptC, ptD, ptE;

    ptA.set(5, -5);
    ptB.set(11, 20);
    ptC.set(20, -200);
    ptD.set(1, 0);
    ptE.set(-8, -8);

    cout << "ptA is " << ptA.get_x();
    cout << ", " << ptA.get_y() << endl;

    cout << "ptB is " << ptB.get_x();
    cout << ", " << ptB.get_y() << endl;

    cout << "ptC is " << ptC.get_x();
    cout << ", " << ptC.get_y() << endl;

    cout << "ptD is " << ptD.get_x();
    cout << ", " << ptD.get_y() << endl;

    cout << "ptE is " << ptE.get_x();
    cout << ", " << ptE.get_y() << endl;

    return 0;
}

void Point::set(int new_x, int new_y) {
    if (new_x < 0)
        new_x *= -1;
    if (new_y < 0)
        new_y *= -1;
    x = new_x;
    y = new_y;
}

int Point::get_x() {
    return x;
}

int Point::get_y() {
    return y;
}

