Exercise 3.2.2:

Here is the pseudo-code for best strategy in the Guess the Number Game.

(Note: it?s assumed that integer division is in use; this automatically rounds down to nearest integer.)

Set lo and hi to the lower and limits of the guessing interval
Make a guess: (lo + hi) / 2
While guess is wrong
     Prompt for feedback from the end user.
     If guess is correct
          Print success message and break out of loop
     Else if guess is too high
          Set hi = guess - 1
     Else if guess is too low
          Set lo = guess + 1
     Make new guess: (lo + hi) / 2


