// Exercise 14.1.3.
// This exercise ensures that no prize is chosen twice
// a row, by using a new data member, "old_index", and
// testing against it.

#include <iostream>
#include <string>
#include <ctime>
using namespace std;


class PrizeManager {
public:
    PrizeManager() {srand(time(NULL)); old_index = -1; }
    string get_good_prize();
    string get_bad_prize();
private:
    int old_index;
};

string PrizeManager::get_good_prize() {
    static const string prize_list[5] = {
       "YOUR BRAND NEW CAR!",
       "A BA-ZILLION DOLLARS!",
       "A EUROPEAN VACATION!",
       "A CONDO IN HAWAII!",
       "TEA WITH THE QUEEN OF ENGLAND!"
     };
     int n = rand() % 5;
     if (n == old_index) {
         n = (n + 1) % 5;
     }
     old_index = n;

     return prize_list[n];
}

string PrizeManager::get_bad_prize() {
    static const string prize_list[8] = {
       "two week's supply of Spam.",
       "a crate of rotting fish heads.",
       "a visit from a circus clown.",
       "two weeks at a clown college.",
       "a ten-year-old VCR player.",
       "a lesson from a mime.",
       "psychoanalysis from a clown.",
       "a tour of the city dump."
     };
     int n = rand() % 8;
     if (n == old_index) {
         n = (n + 1) % 8;
     }
     old_index = n;
      
     return prize_list[n];
}

int main()
{
    int cmd = 0;

    PrizeManager pr_mgr;
    while (true) {
         cout << "Enter command: 1 - good prize, 2 - bad prize, ";
         cout << "3 - exit: ";
         cin >> cmd;
         if (cmd == 1) {
             cout << pr_mgr.get_good_prize() << endl;
         } else if (cmd == 2) {
             cout << pr_mgr.get_bad_prize() << endl;
         } else {
             break;
         }
    }
    return 0;
}


