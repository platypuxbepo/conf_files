// Exercise 9.2.1
// This version of writetxt.cpp enables the user to
// specify how many lines to print at a time.
//

#include <iostream>
#include <fstream>
#include <cstdlib>   // Brings in support for atoi.

using namespace std;
#define COL_WIDTH  80

int num_lines = 24;

int main() {
    char filename[FILENAME_MAX];
    char input_line[COL_WIDTH + 1];

    cout << "Enter a file name and press ENTER: ";
    cin.getline(filename, FILENAME_MAX);

    ifstream file_in(filename);

    if (! file_in) {
        cout << filename << " could not be opened.";
        cout << endl;
        return -1;
    }

    while (true) {
        for(int i = 1; i <= num_lines && ! file_in.eof(); ++i) {
            file_in.getline(input_line, COL_WIDTH);
            cout << input_line << endl;
        }
        if (file_in.eof()) {
            break;
        }
    
    // This next part is the main part that gets modified...
    // If user enters anything at all, it is converted to
    // a number and that becomes the new number of lines to
    // print. A value of 0 indicates the program should quit.

        cout << "More? (Enter # of lines to print): ";
        cin.getline(input_line, COL_WIDTH);
        if (strlen(input_line) > 0) {
             num_lines = atoi(input_line);
        }
        if (num_lines == 0) {
             break;
        }              
    }
    return 0;
}


