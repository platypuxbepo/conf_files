// Exercise 10.3.2
// This version of the file fract2.cpp tests the Fraction
// class by creating five Fraction objects. 

#include <cstdlib>
#include <iostream>
using namespace std;

class Fraction {
private:
    int num, den;      // Numerator and denominator.
public:
    void set(int n, int d)
        {num = n; den = d; normalize();}
    int get_num()  {return num;}
    int get_den()  {return den;}
private:
    void normalize();    // Convert to standard form.
    int gcf(int a, int b);  // Greatest Common Factor.
    int lcm(int a, int b);  // Lowest Common Denom.
};

int main()
{
    Fraction fract_arr[5];
    int num, den;

    for(int i = 0; i < 5; ++i) {
        cout << "For fract_arr[" << i << "]..." << endl;
        cout << "Enter numerator: ";
        cin >> num;
        cout << "Enter denominator: ";
        cin >> den;
        fract_arr[i].set(num, den);
    }
    for(int i = 0; i < 5; ++i) {
        cout << "fract_arr[" << i << "] is: ";
        cout << fract_arr[i].get_num() << "/";
        cout << fract_arr[i].get_den() << endl;
    }
    return 0;
}


// Normalize: put fraction into standard form, unique
//  for each mathematically different value.
//
void Fraction::normalize(){

    // Handle cases involving 0

    if (den == 0 || num == 0) {
        num = 0;
        den = 1;
    }

    // Put neg. sign in numerator only.

    if (den < 0) {
        num *= -1;
        den *= -1;
    }

    // Factor out GCF from numerator and denominator.

    int n = gcf(num, den);
    num /= n;     // <- Div. assignement used here.
    den /= n;     // <- and here.
}

// Greatest Common Factor
//
int Fraction::gcf(int a, int b){
    if (b == 0)
        return abs(a);
    else
        return gcf(b, a%b);
}

// Lowest Common Multiple
//
int Fraction::lcm(int a, int b){
    int n = gcf(a, b);
    return a / n * b;
}

