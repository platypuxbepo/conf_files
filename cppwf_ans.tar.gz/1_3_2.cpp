// Exercise 1.3.2

#include <iostream>
using namespace std;

int main()
{
     double  ctemp;

     cout << "Input a Celsius temp and press ENTER: ";
     cin >> ctemp;
     cout << "Fahrenheit temp is: ";
     cout << (ctemp * 1.8) + 32 << endl;
     return 0;
}

