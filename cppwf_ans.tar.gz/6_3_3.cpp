// Exercise 6.3.3
// This version of the program supports the full range 1 to 99,
// by adding teen names and adding appropriate conditions.

#include <iostream>
#include <string>  // REMEMBER TO INCLUDE THIS!

using namespace std;

string tens_names[ ] = {"", "", "twenty", "thirty", "forty",
   "fifty", "sixty", "seventy", "eighty", "ninety" };

string units_names[ ] = {"", "one", "two", "three", "four",
   "five", "six", "seven", "eight", "nine" };

string teen_names[ ] = {"ten", "eleven", "twelve", "thirteen",
   "fourteen", "fifteen", "sixteen", "seventeen", "eighteen",
   "nineteen" };

int main()
{
    int  n = 0;

    cout << "Enter a number from 1 to 99: ";
    cin >> n;
    
    while (n < 1 || n > 99) {
        cout << "Number out of range. Re-enter: ";
        cin >> n;
    }

    int tens_digits = n / 10;
    int units_digits = n % 10;
    cout << "The number you entered was ";
    if (n > 9 && n < 20) {
        cout << teen_names[units_digits] << endl;
    } else {
        if (n > 19) {
            cout << tens_names[tens_digits] << " ";
        }
        cout << units_names[units_digits] << endl;
    }
    return 0;
}



