// Exercise 1.3.3

#include <iostream>
using namespace std;

int main()
{
     double  x;

     // Input a number.

     cout << "Input a number and press ENTER: ";
     cin >> x;

     // Print the cube of this number.

     cout << "The cube is: ";
     cout << x * x * x << endl;
     return 0;
}

