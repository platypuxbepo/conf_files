// Exercise 1.3.4

#include <iostream>
using namespace std;

int main()
{
     double  num;

     // Input a number.

     cout << "Input a number and press ENTER: ";
     cin >> num;

     // Print the square of this number.

     cout << "The square is: ";
     cout << num * num << endl;
     return 0;
}

