// Exercise 5.5.1

// This version of the tower puzzler solver prompts

// the user for the size of the stack. Note that this

// value must not be less than 1.
// 

#include <iostream>
using namespace std;
void move_rings(int n, int src, int dest, int other);
void move_a_ring(int src, int dest);

int main()
{
    int n = 0;  // In this version, n not set yet.   

    // The next lines prompt for size of stack.

    cout << "Enter the size of the stack: ";
    cin >> n;
    while (n <= 0) {
         cout << "Sorry, n must be > 0. Re-enter: ";
         cin >> n;
    }
    
    move_rings(n, 1, 3, 2); // Move stack 1 to stack 3
    cout << endl;
    return 0;
}

void move_rings(int n, int src, int dest, int other) {
    if (n == 1) {
        move_a_ring(src, dest);
    } else {
        move_rings(n - 1, src, other, dest);
        move_a_ring(src, dest);
        move_rings(n - 1, other, dest, src);
    }
}

void move_a_ring(int src, int dest) {
    cout << "Move from " << src << " to " 
         << dest << endl;
}
