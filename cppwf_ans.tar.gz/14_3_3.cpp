// Exercise 14.3.3
// This program runs the game-show simulation in bulk,
// running each strategy 1000 times, and reports the
// results.
//

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
using namespace std;

class PrizeManager {
public:
    PrizeManager() {}        // <- Random seed no longer set here.
    string get_good_prize();
    string get_bad_prize();
};

string PrizeManager::get_good_prize() {
    static const string prize_list[5] = {
       "YOUR BRAND NEW CAR!",
       "A BA-ZILLION DOLLARS!",
       "A EUROPEAN VACATION!",
       "A CONDO IN HAWAII!",
       "TEA WITH THE QUEEN OF ENGLAND!"
     };
     return prize_list[rand() % 5];
}

string PrizeManager::get_bad_prize() {
    static const string prize_list[8] = {
       "two week's supply of Spam.",
       "a crate of rotting fish heads.",
       "a visit from a circus clown.",
       "two weeks at a clown college.",
       "a ten-year-old VCR player.",
       "a lesson from a mime.",
       "psychoanalysis from a clown.",
       "a tour of the city dump."
     };     
     return prize_list[rand() % 8];
}

class DoorManager {
public:
    DoorManager()  {srand(time(NULL)); }
    void start_new_game();
    void set_sel_door(int n);
    int get_alt_door() { return altDoor + 1; }
    int get_bad_door() { return badDoor + 1; }
    bool query_door(int n) {return n == (winDoor + 1); }
private:
    int winDoor;
    int selDoor, altDoor, badDoor;
};

void DoorManager::start_new_game() {
    winDoor = rand() % 3;
}

void DoorManager::set_sel_door(int n) {
    selDoor = n - 1;
    if (selDoor == winDoor) {
        if (rand() % 2) {  // Random true or false
            altDoor = (selDoor + 1) % 3;
            badDoor = (selDoor + 2) % 3;
        } else {
            badDoor = (selDoor + 1) % 3;
            altDoor = (selDoor + 2) % 3;
        }
    } else { //Else, if the selected door is not the
                // winning door...

         // Alternative door MUST be the winning door!
        altDoor = winDoor;

         // Assign badDoor the number in {0, 1, 2}
         //  not equal to either selDoor or altDoor.
        badDoor = 3 - selDoor - altDoor;
    }
}



void play_game(int door_choice, bool do_switch);
int get_number();

int stay_wins = 0;       // These stats record number of plays for 
int stay_plays = 0;      // each strategy and how often each scored
int switch_wins = 0;     // wins.
int switch_plays = 0;
bool door_is_switched = false;

PrizeManager prize_mgr;
DoorManager  door_mgr;

int main()
{
    srand(time(NULL));     // <- Set random seed here.

   // The following loops play each combination of strategies
   // 1000 times.

    for (int i = 1; i <= 3; ++i) {
        for (int j = 0; j < 1000; ++j) {
            play_game(i, true);
        }
    }
    for (int i = 1; i <= 3; ++i) {
        for (int j = 0; j < 1000; ++j) {
            play_game(i, false);
        }
    }

    // Print out stats.

    if (stay_plays > 0) {
        cout << "Success rate of stay-with-first-choice ";
        cout << "plays: " << (double) stay_wins / stay_plays << endl;
    }
    if (switch_plays > 0) {
        cout << "Success rate of switch-door plays: ";
        cout << (double) switch_wins / switch_plays << endl;
    }
    return 0;
}

void play_game(int door_choice, bool do_switch) {
    int n = door_choice;
    door_mgr.start_new_game();
    door_mgr.set_sel_door(n);
    if (do_switch) {
        ++switch_plays;
        n = door_mgr.get_alt_door();
    } else {
        ++stay_plays;
    }
    if (door_mgr.query_door(n)) {
        if (do_switch) {
            ++switch_wins;
        } else {
            ++stay_wins;
        }
    }
}

int get_number() {
    string sInput;
    while(true) {
         getline(cin, sInput);
         int n = stoi(sInput);
         if (n >= 1 && n <= 3) {
             return n;
         }
         cout << "You must enter 1, 2, or 3. Re-enter: ";
    }
}

