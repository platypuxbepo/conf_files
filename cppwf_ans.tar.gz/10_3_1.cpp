// Exercise 10.3.1
// This version of the file fract2.cpp tests the Fraction
// class by creating five Fraction objects. 

#include <cstdlib>
#include <iostream>
using namespace std;

class Fraction {
private:
    int num, den;      // Numerator and denominator.
public:
    void set(int n, int d)
        {num = n; den = d; normalize();}
    int get_num()  {return num;}
    int get_den()  {return den;}
private:
    void normalize();    // Convert to standard form.
    int gcf(int a, int b);  // Greatest Common Factor.
    int lcm(int a, int b);  // Lowest Common Denom.
};

int main()
{
    Fraction f1, f2, f3, f4, f5;
    f1.set(2, 2);
    f2.set(4, 8);
    f3.set(-9, -9);
    f4.set(10, 50);
    f5.set(100, 25);

    cout << "f1 is " << f1.get_num() << "/" <<
        f1.get_den() << "." << endl;
    cout << "f2 is " << f2.get_num() << "/" <<
        f2.get_den() << "." << endl;
    cout << "f3 is " << f3.get_num() << "/" <<
        f3.get_den() << "." << endl;
    cout << "f4 is " << f4.get_num() << "/" <<
        f4.get_den() << "." << endl;
    cout << "f5 is " << f5.get_num() << "/" <<
        f5.get_den() << "." << endl;

    return 0;
}


// Normalize: put fraction into standard form, unique
//  for each mathematically different value.
//
void Fraction::normalize(){

    // Handle cases involving 0

    if (den == 0 || num == 0) {
        num = 0;
        den = 1;
    }

    // Put neg. sign in numerator only.

    if (den < 0) {
        num *= -1;
        den *= -1;
    }

    // Factor out GCF from numerator and denominator.

    int n = gcf(num, den);
    num /= n;     // <- Div. assignement used here.
    den /= n;     // <- and here.
}

// Greatest Common Factor
//
int Fraction::gcf(int a, int b){
    if (b == 0)
        return abs(a);
    else
        return gcf(b, a%b);
}

// Lowest Common Multiple
//
int Fraction::lcm(int a, int b){
    int n = gcf(a, b);
    return a / n * b;
}

