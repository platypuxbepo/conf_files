// Exercise 3.3.3
// This version of the program handles numbers in the range
// 1 to 999.


#include <iostream>

using namespace std;

int main()
{
    int  n = 0;

    cout << "Enter a number from 1 to 999: ";
    cin >> n;
    int hundreds_digits = n / 100;
    int remainder_from_100 = n % 100;
    int tens_digits = remainder_from_100  / 10;
    int units_digits = remainder_from_100  % 10;

// Here is the new line of code: an if statement...

    if (hundreds_digits > 0) {
         switch(hundreds_digits) {
           case 1: cout << "one hundred"; break;
           case 2: cout << "two hundred"; break;
           case 3: cout << "three hundred"; break;
           case 4: cout << "four hundred"; break;
           case 5: cout << "five  hundred"; break;
           case 6: cout << "sixd hundred"; break;
           case 7: cout << "seven  hundred"; break;
           case 8: cout << "eight hundred"; break;
           case 9: cout << "nine  hundred"; break;
         }
    }
    if (remainder_from_100 > 0) {
        cout << ", ";
    }
    if (remainder_from_100  >= 20) {
         switch(tens_digits) {
           case 2: cout << "twenty "; break;
           case 3: cout << "thirty "; break;
           case 4: cout << "forty "; break;
           case 5: cout << "fifty "; break;
           case 6: cout << "sixty "; break;
           case 7: cout << "seventy "; break;
           case 8: cout << "eighty "; break;
           case 9: cout << "ninety "; break;
        }
    }
    if (remainder_from_100  > 10 &&
        remainder_from_100  < 20) {
         switch(units_digits) {
           case 1: cout << "eleven"; break;
           case 2: cout << "twelve"; break;
           case 3: cout << "thirteen"; break;
           case 4: cout << "fourteen"; break;
           case 5: cout << "fifteen"; break;
           case 6: cout << "sixteen"; break;
           case 7: cout << "seventeen"; break;
           case 8: cout << "eighteen"; break;
           case 9: cout << "nineteen"; break;
         }
    } else {
         switch(units_digits) {
           case 1: cout << "one"; break;
           case 2: cout << "two"; break;
           case 3: cout << "three"; break;
           case 4: cout << "four"; break;
           case 5: cout << "five"; break;
           case 6: cout << "six"; break;
           case 7: cout << "seven"; break;
           case 8: cout << "eight"; break;
           case 9: cout << "nine"; break;
         }
    }

    cout << endl;
    return 0;
}

