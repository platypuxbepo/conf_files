// Exercise 6.2.2
// This version of stats.cpp generates one of 5
// possible values during each trial, instead of 10.

#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int rand_0toN1(int n);
int hits[5];    // Need to store only 5 different stats.

int main()
{
    int n = 0;  // Number of trials; prompt from user

    srand(time(nullptr));   // Set seed for randomizing.

    cout << "Enter how many trials and press ENTER: ";
    cin >> n;

    // Run n trials. For each trial, get a num 0 to 9
    //  and then increment the corresponding element
    //  in the hits array.

    for (int i = 0; i < n; ++i) {
        int r = rand_0toN1(5);  // Generate 1 to 5, not 1 to 10.
        ++hits[r];
    }

    // Print all elements in the hits array, along
    //  with ratio of hits to EXPECTED hits (n / 5.0).

    for (int i = 0; i < 5; ++i) {
       cout << i << ": " << hits[i] << " Accuracy: ";
       double results = hits[i];
       cout << results / (n / 5.0) << endl;
    }
    return 0;
}

// Random 0-to-N1 Function.
// Generate a random integer from 0 to N-1.
//
int rand_0toN1(int n) {
    return rand() % n;
}


