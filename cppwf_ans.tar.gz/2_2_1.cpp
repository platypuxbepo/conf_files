// Exercise 2.2.1
// This program prints all the numbers from n1 to n2,
//  in which both numbers are specified by the user.


#include <iostream>
using namespace std;

int main()
{
    int  i, n1, n2;

    // Get number from the keyboard and initialize i.

    cout << "Enter the lower number and press ENTER: ";
    cin >> n1;
    cout << "Enter the upper number and press ENTER: ";
    cin >> n2;
    i = n1;

    while (i <= n2) {     // While i is greater than zero,
        cout << i << " ";   //   Print i,
        i = i + 1;          //   Add 1 to i.
    }
    cout << endl;
    return 0;
}


