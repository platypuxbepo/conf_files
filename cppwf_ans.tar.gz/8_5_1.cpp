// Exercise 8.5.1
// This is a string-building program using the STL
// string class.
//

#include <iostream>
#include <string>    // Include support for string class.
using namespace std;

int main()
{
    string str, name, breed, age;

    // Get three strings from the user.

    cout << "Enter dog's name and press ENTER: ";
    getline(cin, name);
    cout << "Enter breed and press ENTER: ";
    getline(cin, breed);
    cout << "Enter dog's age and press ENTER: ";
    getline(cin, age);

    // Build the output string, and then print it.

    str = "My name is " + name + ", " +
          "my breed is " + breed +
          ",\nand my age is " + age + ".\n";

    cout << endl << str << endl;
    return 0;
}
