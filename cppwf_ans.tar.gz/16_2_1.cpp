// Exercise 16.2.1
// This exercise prints the value of a Point object
// by calling a virtual function, print_me, by using
// a pointer to the base class.

#include <iostream>
using namespace std;

class IPrintable {
    virtual void print_me(ostream &os) = 0;
    
    friend ostream &operator<<(ostream &os, IPrintable &pr);
};

// Operator<< function
//
ostream& operator<<(ostream &os, IPrintable &pr) {
    pr.print_me(os);
    return os;
};


// The Point class declaration now inherits from base
// class Printable, and implements print_me().

class Point : public IPrintable {
private:            // Data members (private)
    int x, y;
public:              // Member functions
    Point() {set(0, 0);}
    Point(int new_x, int new_y) 
        {set(new_x, new_y);}
    void set(int new_x, int new_y);
    int get_x();
    int get_y();
    void print_me(ostream &os);
};

int main() {
    IPrintable *p = new Point(10, -20);

    cout << "The value of the object is " << *p;
    cout << endl;        
        
    return 0;
}

void Point::set(int new_x, int new_y) {
    if (new_x < 0)
        new_x *= -1;
    if (new_y < 0)
        new_y *= -1;
    x = new_x;
    y = new_y;
}

int Point::get_x() {
    return x;
}

int Point::get_y() {
    return y;
}

void Point::print_me(ostream &os) {
    os << "(" << get_x() << ", " << get_y();
    os << ")";
}
