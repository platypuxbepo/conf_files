// Exercise 5.6.2

// This file includes a random-num generator that produces

// a double (floating pt) in the range 0.0 to 1.0.

// 
// Note that #include <cstdlib> and using namespace std;

// are assumed.


// Another way to do this is with static_cast<double>(), but

// the following way is shorter. Floating-pt division needs

// to be forced through type promotion.



double rand_0to1() {

    double r = rand();

    return r / RAND_MAX;

}