// Exercise 4.1.3
// This program prints numbers from 1 to n,
// but increasing two at a time, which will produce
// odd numbers only.


#include <iostream>
using namespace std;

int main()
{
    int  i = 0;   // Loop counter in "for" statement.
    int  n = 0;

    // Get num from the keyboard.

    cout << "Enter n and press ENTER: ";
    cin >> n;

    for (i = 1; i < n; i += 2){   // For i to n BY 2,
        cout << i << " ";         //    Print i.
    }
    cout << endl;
    return 0;
}

