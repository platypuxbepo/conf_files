// Exercise 13.1.4.
// This exercise reports data on a list of doubles.

#include <iostream>
#include <list>
#include <string>

using namespace std;

int main()
{
        string s;   // Input string
	list<double> the_list;
	list<double>::iterator iter;
        double x = 0.0;
        double total = 0.0;
        double low = 0.0;
        double high = 0.0;

	while (true) {
		cout << "Enter string (ENTER to exit): ";
		getline(cin, s);
		if (s.size() == 0) {
			break;
		}
                x = stof(s);
		for (iter = the_list.begin(); iter != the_list.end()
                        && x < *iter; iter++) {
		}
		the_list.insert(iter, x);
                total += x;
                if (x < low || the_list.size == 1) {
                    low = x;
                }
                if (x > high || the_list.size == 1) {
                    high = x;
                }
	}
        cout << "Lowest value is: " << low << endl;
        cout << "Highest value is: " << high << endl;
        cout << "Total is: " << total << endl;
        cout << "Average is: " << (total/the_list.size()) << endl;
	return 0;
}

