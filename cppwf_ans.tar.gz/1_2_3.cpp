// Exercise 1.2.3

#include <iostream>
using namespace std;

int main()
{
    cout << "I am Blaxxon," << endl << endl << endl;
    cout << "the cosmic computer." << endl << endl << endl;
    cout << "Fear me!" << endl << endl << endl;
    return 0;
}