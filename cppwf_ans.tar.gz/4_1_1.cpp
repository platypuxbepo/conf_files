// Exercise 4.1.1
// This program uses "for" to print all the numbers
// from n1 to n2.

#include <iostream>
using namespace std;

int main()
{
    int  n1 = 0, n2 = 0;  // Boundaries for loop.
    int  i = 0;   // Loop counter in "for" statement.

    // Get num from the keyboard and initialize i.

    cout << "Enter n1 and press ENTER: ";
    cin >> n1;
    cout << "Enter n2 and press ENTER: ";
    cin >> n2;
 
    for (i = n1; i <= n2; ++i){   // For i = 1 to n
        cout << i << " ";       //    Print i.
    }
    cout << endl;
    return 0;
}

