// Exercise 9.2.2
// This version of writetxt.cpp prints all file
// text in all uppercase.
//

#include <iostream>
#include <fstream>
#include <cctype>  // Turns on suport for toupper() lib. function.

using namespace std;
#define COL_WIDTH  80

char* convert_to_upper(char *s);  // Convert all chars in string
                                 // s to uppercase.

int main() {
    int  c; // Input character
    char filename[FILENAME_MAX];
    char input_line[COL_WIDTH + 1];

    cout << "Enter a file name and press ENTER: ";
    cin.getline(filename, FILENAME_MAX);

    ifstream file_in(filename);

    if (! file_in) {
        cout << filename << " could not be opened.";
        cout << endl;
        return -1;
    }

    while (true) {
        for(int i = 1; i <= 24 && ! file_in.eof(); ++i) {
            file_in.getline(input_line, COL_WIDTH);
            cout << convert_to_upper(input_line) << endl;
        }
        if (file_in.eof()) {
            break;
        }
        cout << "More? (Press 'Q' and ENTER to quit)";
        cin.getline(input_line, COL_WIDTH);
        c = input_line[0];
        if (c == 'Q' || c == 'q') {
            break;
        }
    }
    return 0;
}

char* convert_to_upper(char *s) {
    for (int i = 0; i < strlen(s); ++i) {
        s[i] = toupper(s[i]);
    }
    return s;
}

