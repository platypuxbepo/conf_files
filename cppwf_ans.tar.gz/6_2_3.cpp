// Exercise 6.2.3
// This version of stats.cpp generates a number
// of different values, and this range is dictated
// by a #define.

#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

#define VALUES  5

int rand_0toN1(int n);
int hits[VALUES]; 

int main()
{
    int n = 0;  // Number of trials; prompt from user

    srand(time(nullptr));   // Set seed for randomizing.

    cout << "Enter how many trials and press ENTER: ";
    cin >> n;

    // Run n trials. For each trial, get a num 0 to 9
    //  and then increment the corresponding element
    //  in the hits array.

    for (int i = 0; i < n; ++i) {
        int r = rand_0toN1(VALUES);  // Generate 1 to VALUES.
        ++hits[r];
    }

    // Print all elements in the hits array, along
    // with ratio of hits to EXPECTED hits (n / VALUES).
    // Note that (n / VALUES) has to be modified to 
    // guarantee floating-pt division.

    for (int i = 0; i < VALUES; ++i) {
       cout << i << ": " << hits[i] << " Accuracy: ";
       double results = hits[i];
       double x = n;   // Promote n to double, so that
                       // x / VALUES uses floating division.
       cout << results / (x / VALUES) << endl;
    }
    return 0;
}

// Random 0-to-N1 Function.
// Generate a random integer from 0 to N-1.
//
int rand_0toN1(int n) {
    return rand() % n;
}

