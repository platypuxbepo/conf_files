The default action of the "Play again?" question is to go ahead and 
play the game another time, because only a 'N' or 'n' response causes
the program to exit.
