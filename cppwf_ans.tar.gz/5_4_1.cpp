// Exercise 5.4.1
// This version of the GCF (Greatest Common Factor) 
// function prints out each step of the recursion.

#include <iostream>
using namespace std;
int gcf(int a, int b);

int main()
{
    int a = 0, b = 0; // Inputs to GCF.

    cout << "Enter a: ";
    cin >> a;
    cout << "Enter b: ";
    cin >> b;
    cout << gcf(a, b) << endl;
    return 0;
}

// CGF function. Major change from example in
// book is in the first line within this definition.

int gcf(int a, int b) {
    cout << "GCF(" << a << ", " << b << ") ==> " << endl;
    if (b == 0) {
        return a;
    } else {
        return gcf(b, a%b);
    }
}

