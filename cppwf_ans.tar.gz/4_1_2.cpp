// Exercise 4.1.2
// This program prints all the numbers from n to 1
// in a downward (reverse) order.


#include <iostream>
using namespace std;

int main()
{
    int  i = 0;   // Loop counter in "for" statement.
    int  n = 0;

    // Get num from the keyboard.

    cout << "Enter n and press ENTER: ";
    cin >> n;

    for (i = n; i > 0; --i){   // For i = n DOWN TO 1
        cout << i << " ";      //    Print i.
    }
    cout << endl;
    return 0;
}

