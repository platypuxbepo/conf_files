// Exercise 2.2.3
// This program prints even numbers only, but stops
// after the most recent number is >= n.

#include <iostream>
using namespace std;

int main()
{
    int  i = 0, n;

    // Get number from the keyboard.

    cout << "Enter a number and press ENTER: ";
    cin >> n;

    while (i <= n) {     // While i is greater than zero,
        cout << i << " ";   //   Print i,
        i = i + 2;          //   Add 2 to i.
    }
    cout << endl;
    return 0;
}


