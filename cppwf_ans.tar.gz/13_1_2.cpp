// Exercise 13.1.2
// This exercise uses continually sorted list,
// but keeps it in reverse order.

#include <iostream>
#include <list>
#include <string>

using namespace std;

int main()
{
	string s;
	list<string> LS;
	list<string>::iterator iter;

	while (true) {
		cout << "Enter string (ENTER to exit): ";
		getline(cin, s);
		if (s.size() == 0) {
			break;
		}

                // Note that only change needed from last exercise
                // is to reverse the comparison here from > to <.

		for (iter = LS.begin(); iter != LS.end() && s < *iter;
			iter++) {
		}
		LS.insert(iter, s);    // <- Here is where insertion is made!
	}
	for (iter = LS.begin(); iter != LS.end(); iter++) {
		cout << *iter << endl;
	}

	return 0;
}

