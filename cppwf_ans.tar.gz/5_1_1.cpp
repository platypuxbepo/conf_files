// Exercise 5.1.1
// This program defines a factorial function and tests it.
//

#include <iostream>

using namespace std;

int factorial(int n);

int main()
{
    int  n = 0;   // Number to test for prime-ness

    // Get a number from the keyboard.

    cout << "Enter a number and press ENTER: ";
    cin >> n;
    
    // Print the resulting factorial after calling
    // the function.

    cout << "factorial(" << n << ") = " << factorial(n);
    cout << endl;

    return 0;
}

int factorial(int n) {
    int amt = 1;

    for(int i = 2; i <= n; ++i) {
        amt *= i;
    }
    return amt;
}
