// Exercise 8.2.1
// This version of the getnum function returns
// an integer instead of a double.

#include <iostream>
#include <cstring>
#include <cmath>
#include <cstdlib>
using namespace std;

int get_number();  // In this version, ret. type is int.

int main()
{
    int n = 0;     // In this version, n declared as int.

    while(true) {
        cout << "Enter a num (press ENTER to exit): ";
        n = get_number();
        if (n == 0) {
            break;
        }
        cout << "Square root of num is: " << sqrt(n);
        cout << endl;
    }
    return 0;
}

// Get-number function.
// Get number input by the user, taking only the first
//  numeric input entered. If user presses ENTER with
//  no input, then return a default value of 0.
//
int get_number() {
    char s[100];

    cin.getline(s, 100);
    if (strlen(s) == 0) {
        return 0;     // 0 is default, not 0.0
    }
    return atoi(s);   // Note use of atoi here, not atof.
}

