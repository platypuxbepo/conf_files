// Exercise 1.1.3

#include <iostream>
using namespace std;

int main()
{
    cout << "Do you C++? ";
    return 0;
}