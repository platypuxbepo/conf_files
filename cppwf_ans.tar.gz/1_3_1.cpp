// Exercise 1.3.1

#include <iostream>
using namespace std;

int main()
{
     double  ctemp, ftemp;

     cout << "Input a Fahrenheit temp and press ENTER: ";
     cin >> ftemp;
     ctemp = (ftemp - 32.0) / 1.8;
     cout << "Centigrade temp is: " << ctemp << endl;
     return 0;
}

