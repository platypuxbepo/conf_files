// Exercise 10.4.3
// This exercise creates an "add" function for the Point
// class.

#include <iostream>
using namespace std;

class Point {
private:            // Data members (private)
    int x, y;
public:              // Member functions
    void set(int new_x, int new_y);
    int get_x();
    int get_y();

    // The following decl. defines an add member function.

    Point add(Point other) {
        Point pt;
        pt.set(x + other.x, y + other.y);
        return pt;
    }
};


int main() {
    Point pnt;
    return 0;
}


void Point::set(int new_x, int new_y) {
    if (new_x < 0)
        new_x *= -1;
    if (new_y < 0)
        new_y *= -1;
    x = new_x;
    y = new_y;
}

int Point::get_x() {
    return x;
}

int Point::get_y() {
    return y;
}


