// Exercise 7.3.1
// This version of the sort program sorts from high to low.
//

#include <iostream>
using namespace std;

void sort(int n);
void swap(int *p1, int *p2);

int a[10];

int main ()
{
    for (int i = 0; i < 10; ++i) {
        cout << "Enter array element #" << i << ": ";
        cin >> a[i];
    }
    sort(10);

    cout << "Here is the array, sorted:" << endl;
    for (int i = 0; i < 10; ++i) {
        cout << a[i] << "  ";
    }
    cout << endl;
    return 0;
}

// Sort function: sort array named a with n elements.
// This version searches for, and puts high elements,
// first.
//
void sort (int n) {
    int hi = 0;

    for(int i = 0; i < n - 1; ++i) {

        // This part of the loop finds the highest
        //  element in the range i to n-1; the index
        //  is set to the variable named low.

        hi = i;
        for (int j = i + 1; j < n; ++j) {
            if (a[j] > a[hi]) {
                hi = j;
            }
        }

        // This part of the loop performs a swap if
        //  needed.

        if (i != hi) {
            swap(&a[i], &a[hi]);
        }
    }
}

// Swap function.
// Swap the values pointed to by p1 and p2.
//
void swap(int *p1, int *p2) {
    int temp = *p1;
    *p1 = *p2;
    *p2 = temp;
}

