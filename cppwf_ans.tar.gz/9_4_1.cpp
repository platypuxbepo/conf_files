// Exercise 9.4.1
// This version of the readbin.cpp program reads records
// containing model, make, year, and mileage.
//

#include <iostream>
#include <fstream>
#include <cstring>    // Needed to support strlen
#include <cstdlib>    // Needed to support atoi

using namespace std;

int get_int(int default_value);

int main() {
    char filename[FILENAME_MAX];
    int n = 0;

    char model[20];
    char make[20];
    char year[5];
    int mileage;
    int recsize =  sizeof(model) + sizeof(make) + sizeof(year) + 
         sizeof(int);
    

    cout << "Enter file name: ";
    cin.getline(filename, FILENAME_MAX);

    // Open file for binary read-write access.

    fstream  fbin(filename, ios::binary | ios::in);
    if (!fbin) {
        cout << "Could not open " << filename << endl;
        return -1;
    }

    // Get record number and go to record.

    cout << "Enter file record number: ";
    n = get_int(0);
    fbin.seekp(n * recsize);

    // Read data from the file.

    fbin.read(model, sizeof(model) - 1);
    fbin.read(make, sizeof(make) - 1);
    fbin.read(year, sizeof(year) - 1);
    fbin.read((char*)(&mileage), sizeof(int));

    // Display the data and close.
    
    cout << "The model is: " << model << endl;
    cout << "The make is: " << make << endl;
    cout << "The year is: " << year << endl;
    cout << "The mileage is: " << mileage << endl;

    fbin.close();
    return 0;
}

// Get integer function
// Get an integer from keyboard; return default
//  value if user enters 0-length string.
//
int get_int(int default_value) {
    char s[81];

    cin.getline(s, 80);
    if (strlen(s) == 0) {
         return default_value;
    }
    return atoi(s);
}

