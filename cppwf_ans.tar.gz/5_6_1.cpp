// Exercise 5.6.1

// This file includes a random-num generator that produces

// an integer in the range 1 to n.

// 
// Note that #include <cstdlib> and using namespace std;

// are assumed.


int rand_1toN(int n) {
 
    return rand % n + 1;

}