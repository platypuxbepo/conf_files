// Exercise 1.2.1

#include <iostream>
using namespace std;

int main()
{
    cout << "I am Blaxxon,";
    cout << "the cosmic computer.";
    cout << "Fear me!";
    cout << endl;
    return 0;
}