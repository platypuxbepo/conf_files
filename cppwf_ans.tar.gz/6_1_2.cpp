// Exercise 6.1.2
// This version of the array printing program prints
// six integers and keeps a running total.

#include <iostream>
using namespace std;

int main()
{
    int sum = 0;  // Running total kept here.

    int scores[6] = {10, 22, 13, 99, 4, 5};

    for(int i = 0; i < 6; ++i) {
        cout << scores[i] << "  ";
        sum += scores[i];
    } 
    cout << endl << "The sum is: " << sum << endl;
    return 0;
}



