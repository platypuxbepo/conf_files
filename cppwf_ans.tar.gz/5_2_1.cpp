// Exercise 5.2.1
//

#include <iostream>

using namespace std;

void print_out(int n);

int main()
{
    int  n = 0;   // Number to test for prime-ness

    // Get a number from the keyboard.

    cout << "Enter a number and press ENTER: ";
    cin >> n;
    
    // Call the print_out function.

    print_out(n);
    return 0;
}

void print_out(int n) {
    for(int i = 1; i <= n; ++i) {
        cout << i << "  ";
    }
    cout << endl;
}
                   