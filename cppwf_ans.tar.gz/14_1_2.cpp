// Exercise 14.1.2.
// This exercise tests out the PrizeManager class while
// adding one string each to the good prize and bad
// prize lists.

#include <iostream>
#include <string>
#include <ctime>
using namespace std;


class PrizeManager {
public:
    PrizeManager() {srand(time(NULL));}
    string get_good_prize();
    string get_bad_prize();
};

string PrizeManager::get_good_prize() {
    static const string prize_list[6] = {
       "YOUR BRAND NEW CAR!",
       "A BA-ZILLION DOLLARS!",
       "A EUROPEAN VACATION!",
       "A CONDO IN HAWAII!",
       "TEA WITH THE QUEEN OF ENGLAND!",
       "PUREBRED PUPPIES!"
     };
     return prize_list[rand() % 6];
}

string PrizeManager::get_bad_prize() {
    static const string prize_list[9] = {
       "two week's supply of Spam.",
       "a crate of rotting fish heads.",
       "a visit from a circus clown.",
       "two weeks at a clown college.",
       "a ten-year-old VCR player.",
       "a lesson from a mime.",
       "psychoanalysis from a clown.",
       "a tour of the city dump.",
       "a can of garbage."
     };     
     return prize_list[rand() % 9];

}


int main()
{
    int cmd = 0;

    PrizeManager pr_mgr;
    while (true) {
         cout << "Enter command: 1 - good prize, 2 - bad prize, ";
         cout << "3 - exit: ";
         cin >> cmd;
         if (cmd == 1) {
             cout << pr_mgr.get_good_prize() << endl;
         } else if (cmd == 2) {
             cout << pr_mgr.get_bad_prize() << endl;
         } else {
             break;
         }
    }
    return 0;
}

