// Exercise 6.1.1
// This version of the array printing program prints
// eight integers rather than five double-precision nuts.

#include <iostream>
using namespace std;

int main()
{
    // Note that the array is now declared as int.

    int scores[8] = {15, 25, 35, 45, 55, 65, 75, 85};

    for(int i = 0; i < 8; ++i) {
        cout << scores[i] << "  ";
    }
    cout << endl;
    return 0;
}
