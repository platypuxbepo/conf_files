// Exercise 8.6.2
// This version of get_num gets a floating-point value
// from the end user rather than int.
//

#include <iostream>
#include <string>    // Include support for string class.
using namespace std;

bool get_next_num(double *p);   // <- Note decl.

int main()
{
     double sum = 0.0;
     double x = 0.0;

     while (get_next_num(&x)) {
          sum += x;
     }
     cout << "The total is: " << sum << endl;
     return 0;
}

bool get_next_num(double *p) {
     string input_line;
     cout << "Enter num (press ENTER to quit): ";
     getline(cin, input_line);
     if (input_line.size() == 0) {
          return false;
     }
     *p = stof(input_line);   // <- Note use of stof.
     return true;
}

