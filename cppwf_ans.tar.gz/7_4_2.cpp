// Exercise 7.4.2
// This program uses direct pointer references to copy
// one array to another, and then to print out the 
// that received the values.
//

#include <iostream>

using namespace std;

void copy_array(int *p1, int *p2, int n); // Copy a[] from b[].

int a[10];
int b[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

int main() {
    copy_array(a, b, 10);

    // Print out all the elements of array a.

    for (int *p = a; p < a + 10; ++p) {
        cout << *p << "  ";
    }
    cout << endl;
    return 0;
}

// Copy array a[] from array b[].
// n is the size of both arrays.
//

void copy_array(int *p1, int *p2, int n) {
    while(n-- > 0) {
       *p1++ = *p2++;
    }
}
