// Exercise 3.2.1
// This program uses while without do.
// Because do_more is initialized to true, it is
// safe to test it at the top of the loop.
//

#include <iostream>
#include <cstdlib>    // Supports rand and srand functions.
#include <ctime>      // Supports time function.

using namespace std;

int main()
{
    int  n = 0;
    bool do_more = true;

    srand(time(nullptr));         // Set random seed.
    int target = rand() % 50 + 1; // Get random 1-50.

    while (do_more) {
        cout << "Enter your guess: ";
        cin >> n;
        if (n == 0) {
            cout << "Bye! ";
            do_more = false;
        } else if (n > target) {
            cout << "Guess is too high. ") << endl;
        } else if (n < target) {
            cout << "Guess is too low. ") << endl;
        } else {
            cout << "You win! ";
            cout << "Answer is " << n << endl;
            do_more = false;
        }
    }

    return 0;
}

