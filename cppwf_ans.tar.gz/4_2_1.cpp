// Exercise 4.2.1
// This is the revised prime-number program, rewritten so
// as to be more optimal in terms of execution speed (even
// though the program will be two lines longer). This is
// done by:
// 1) Calculating square root of n only once.
// 2) Breaking out of the loop as soon as possible, using the
//  "break" statement.

#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    int  n = 0;   // Number to test for prime-ness
    bool is_prime = true; // Boolean flag; assume true
                          //   until proven otherwise

    // Get a number from the keyboard.

    cout << "Enter a number and press ENTER: ";
    cin >> n;
    
    // Test for prime by checking for divisibility
    //  by all whole numbers from 2 to sqrt(n).

    double sqrt_of_n = sqrt(n);    // New line of code!
    for (int i = 2; i <= sqrt(n); ++i) {
        if (n % i == 0) {
            is_prime = false;
            break;                 // Other new line of code!
        }
    }

    // Print results

    if (is_prime) {
        cout << "Number is prime." << endl;
    } else {
        cout << "Number is not prime." << endl;
    }
    return 0;
}

