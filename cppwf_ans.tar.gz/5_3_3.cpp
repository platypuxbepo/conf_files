// Exercise 5.3.3
// This version of the get all divisors function
// continues until the user presses 0 to exit.


#include <iostream>
#include <cmath>      // Include because sqrt is called.

using namespace std;

void get_all_divisors(int n);
int get_lowest_divisor(int n);

int main()
{
    while (true) {
         int n = 0;
         cout << "Enter a number (ENTER to exit): ";
         cin >> n;
         if (n == 0) {
              break;
         }
         get_all_divisors(n);
         cout << endl;
    }
    return 0;
}

// Get all divisors function. Call get_lower_divisor
// function iteratively; printing a divisor and calling
// it again by dividing by the result.

void get_all_divisors(int n) {
     int result = get_lowest_divisor(n);
     while (result < n) {
         cout << result << ", ";
         n = n / result;
         result = get_lowest_divisor(n);
     }
     cout << n << endl;
}

// Get lowest divisor function.
// Returns the lowest divisor found other than 1.

int get_lowest_divisor(int n) {
     double sqrt_of_n = sqrt(n);
     for (int i = 2; i <= sqrt_of_n; ++i) {
         if (n % i == 0) {      // If i divides n evenly,
             return i;          //  exit.
         }
     }
     return n;   
}
    

