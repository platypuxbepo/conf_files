// Exercise 14.2.3.
// This version of the DoorManager class (which is tested),
// uses values 1, 2, and 3 for the doors rather than 0, 1,
// and 2, even though this complicates some of the math.
//

#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

// Exercise 14.2.2.
//

#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;


class DoorManager {
public:
	DoorManager() { srand(time(NULL)); }
	void start_new_game();
	void set_sel_door(int n);
	int get_alt_door() { return altDoor + 1; }
	int get_bad_door() { return badDoor + 1; }
	bool query_door(int n) { return n == (winDoor + 1); }
private:
	int winDoor;
	int selDoor, altDoor, badDoor;
};


int main()
{
	int choice = 0;
	DoorManager door_mgr;

	while (true) {
		cout << "Select Door No. 1, 2, 3 (0 to exit): ";
		cin >> choice;
		if (choice < 1 || choice > 3) {
			break;
		}
		door_mgr.start_new_game();
		door_mgr.set_sel_door(choice);
		cout << "Alt door is: " << door_mgr.get_alt_door() << endl;
		cout << "Bad door is: " << door_mgr.get_bad_door() << endl;
		cout << "Result of query door is: ";
		cout << door_mgr.query_door(choice) << endl;
	}
	return 0;
}

void DoorManager::start_new_game() {
	winDoor = rand() % 3;
}

void DoorManager::set_sel_door(int n) {
	selDoor = n - 1;
	if (selDoor == winDoor) {
		if (rand() % 2) {  // Random true or false
			altDoor = (selDoor + 1) % 3;
			badDoor = (selDoor + 2) % 3;
		}
		else {
			badDoor = (selDoor + 1) % 3;
			altDoor = (selDoor + 2) % 3;
		}
	}
	else {

		altDoor = winDoor;

		badDoor = 3 - selDoor - altDoor;
	}
}

