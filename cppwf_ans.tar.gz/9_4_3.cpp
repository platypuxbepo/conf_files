// Exercise 9.4.3
// This program both reads and writes binary records.
//

#include <iostream>
#include <fstream>
#include <cstring>    // Needed to support strlen
#include <cstdlib>    // Needed to support atoi

using namespace std;

fstream fbin;

void read_recs();
void write_recs();
int get_int(int default_value);

char name[20];  // These vars need to be global because
int age = 0;    //  they are shared.
int recsize;

int main() {
    char filename[FILENAME_MAX];
    int n = 0;
    
    recsize =  sizeof(name) + sizeof(int);
    

    cout << "Enter file name: ";
    cin.getline(filename, FILENAME_MAX);

    // Open file for binary read-write access.

    fbin.open(filename, ios::binary | ios::in | ios::out);
    if (!fbin) {
        cout << "Could not open " << filename << endl;
        return -1;
    }

    while (true) {
        int cmd = 0;

        // Get a command number and execute the command.

        cout << "Enter command no. 1 - read, 2 - write, 3 - exit: ";
        cmd = get_int(3);
        if (cmd == 1) {
             read_recs();
        } else if (cmd == 2) {
             write_recs();
        } else {
             break;
        }
    }
    fbin.close();
    return 0;
}

void read_recs() {
    while (true) {
        int n = 0;  

        cout << "Enter file record number (-1 to quit): ";
        n = get_int(-1);
        if(n == -1) {
             break;
        }

        fbin.seekp(n * recsize);

        // Read data from the file.

        fbin.read(name, sizeof(name));
        fbin.read((char*)(&age), sizeof(int));

        // Display the data.
    
        cout << "The name is: " << name << endl;
        cout << "The age is: " << age << endl;
    }
}

void write_recs() {
    while (true) {
        int n = 0;  

        cout << "Enter file record number (-1 to quit): ";
        n = get_int(-1);
        if(n == -1) {
             break;
        }

        fbin.seekp(n * recsize);

        cout << "Enter name: ";
        cin.getline(name, sizeof(name));
        cout << "Enter age: ";
        age = get_int(0);

        // Write data to the file.

        fbin.write(name, sizeof(name));
        fbin.write((char*)(&age), sizeof(int));
    }
}

// Get integer function
// Get an integer from keyboard; return default
//  value if user enters 0-length string.
//
int get_int(int default_value) {
    char s[81];

    cin.getline(s, 80);
    if (strlen(s) == 0) {
         return default_value;
    }
    return atoi(s);
}

